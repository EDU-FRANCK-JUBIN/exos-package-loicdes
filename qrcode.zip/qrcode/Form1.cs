﻿using iText.Kernel.Pdf;
using iText.Layout;
using iText.Layout.Element;
using iText.Layout.Properties;
using QRCoder;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace qrcode
{
    public partial class Form1 : Form
    {
        public static readonly string DEST = "gang.pdf";
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void generate_Click(object sender, EventArgs e)
        {
            FileInfo file = new FileInfo(DEST);
            file.Directory.Create();
            QRCodeGenerator qrGenerator = new QRCodeGenerator();
            QRCodeData qrCodeData = qrGenerator.CreateQrCode(this.tx_url.Text, QRCodeGenerator.ECCLevel.Q);
            QRCode qrCode = new QRCode(qrCodeData);
            Bitmap qrCodeImage = qrCode.GetGraphic(5, Color.White, Color.Red, true);
            this.QRcodeContainer.Image = qrCodeImage;
            this.QRcodeContainer.Refresh();

            PdfDocument pdfDoc = new PdfDocument(new PdfWriter(DEST));
            Document doc = new Document(pdfDoc);
            Table table = new Table(UnitValue.CreatePercentArray(8)).UseAllAvailableWidth();

            for (int i = 0; i < 16; i++)
            {
                table.AddCell("hi");
            }

            doc.Add(new Paragraph(tx_url.Text));
            doc.Close();
        }
    }
}
