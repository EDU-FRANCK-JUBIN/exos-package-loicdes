﻿namespace qrcode
{
    partial class Form1
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.QRcodeContainer = new System.Windows.Forms.PictureBox();
            this.tx_url = new System.Windows.Forms.RichTextBox();
            this.generate = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.QRcodeContainer)).BeginInit();
            this.SuspendLayout();
            // 
            // QRcodeContainer
            // 
            this.QRcodeContainer.Location = new System.Drawing.Point(12, 12);
            this.QRcodeContainer.Name = "QRcodeContainer";
            this.QRcodeContainer.Size = new System.Drawing.Size(334, 317);
            this.QRcodeContainer.TabIndex = 0;
            this.QRcodeContainer.TabStop = false;
            // 
            // tx_url
            // 
            this.tx_url.Location = new System.Drawing.Point(450, 56);
            this.tx_url.Name = "tx_url";
            this.tx_url.Size = new System.Drawing.Size(329, 34);
            this.tx_url.TabIndex = 1;
            this.tx_url.Text = "https://www.youtube.com/watch?v=T_Ltf50RAKY";
            // 
            // generate
            // 
            this.generate.Location = new System.Drawing.Point(541, 211);
            this.generate.Name = "generate";
            this.generate.Size = new System.Drawing.Size(135, 46);
            this.generate.TabIndex = 2;
            this.generate.Text = "Generate QRCode";
            this.generate.UseVisualStyleBackColor = true;
            this.generate.Click += new System.EventHandler(this.generate_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(863, 341);
            this.Controls.Add(this.generate);
            this.Controls.Add(this.tx_url);
            this.Controls.Add(this.QRcodeContainer);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.QRcodeContainer)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        public System.Windows.Forms.PictureBox QRcodeContainer;
        private System.Windows.Forms.RichTextBox tx_url;
        private System.Windows.Forms.Button generate;
    }
}

